#include <Arduino.h>
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <Wire.h>
#include <LittleFS.h>

// MAX30102
#include "MAX30105.h"
#include "heartRate.h"

// MPU-9250
#include <MPU9250_asukiaaa.h>

#define EMG_PIN 34
#define SAMPLE_HZ 20
#define SAMPLE_MS (1000 / SAMPLE_HZ)

const char* AP_SSID = "NeuroShield-AP";
const char* AP_PASS = "neuroshield123";

AsyncWebServer server(80);
AsyncWebSocket ws("/stream");

// MAX30102 objects
MAX30105 particleSensor;
const byte RATE_SIZE = 4;
byte rates[RATE_SIZE];
byte rateSpot = 0;
long lastBeat = 0;
float beatsPerMinute = 0;
int beatAvg = 0;

// MPU-9250 object
MPU9250_asukiaaa myIMU;

void sensorsInit() {
  analogReadResolution(12);
  analogSetPinAttenuation(EMG_PIN, ADC_11db);

  // MAX30102 init
  Wire.begin(21,22);
  if (!particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("MAX30102 not found. Check wiring.");
  }
  particleSensor.setup();
  particleSensor.setPulseAmplitudeRed(0x0A);
  particleSensor.setPulseAmplitudeIR(0x0A);
  particleSensor.setPulseAmplitudeGreen(0);

  // MPU9250 init
  myIMU.setWire(&Wire);
  myIMU.beginAccel();
  myIMU.beginGyro();
  myIMU.beginMag();
}

float readEMG() {
  int raw = analogRead(EMG_PIN); // 0..4095
  return (float)raw;
}

float readPPG() {
  long irValue = particleSensor.getIR();
  if (checkForBeat(irValue) == true) {
    long delta = millis() - lastBeat;
    lastBeat = millis();
    beatsPerMinute = 60 / (delta / 1000.0);
    if (beatsPerMinute < 255 && beatsPerMinute > 20) {
      rates[rateSpot++] = (byte)beatsPerMinute;
      rateSpot %= RATE_SIZE;
      beatAvg = 0;
      for (byte x = 0; x < RATE_SIZE; x++)
        beatAvg += rates[x];
      beatAvg /= RATE_SIZE;
    }
  }
  return (float)beatAvg; // BPM
}

float readMOV() {
  myIMU.accelUpdate();
  float ax=myIMU.accelX(), ay=myIMU.accelY(), az=myIMU.accelZ();
  float mag=sqrtf(ax*ax+ay*ay+az*az);
  return mag; // g magnitude
}

// crude seizure rule from your dataset
bool detectSeizure(float bpm, float emg, float mov) {
  bool condPPG = (bpm > 120 || bpm < 50);   // high or low HR
  bool condEMG = (emg > 1300 && emg < 2500); // raw EMG range
  bool condMOV = (mov < 0.3);                // little movement
  return (condPPG && condEMG && condMOV);
}

// send one row to all WebSocket clients
void sendOneRow() {
  float ppg = readPPG();
  float emg = readEMG();
  float mov = readMOV();
  bool seizure = detectSeizure(ppg,emg,mov);
  char line[128];
  snprintf(line,sizeof(line),"%.1f\t%.0f\t%.2f\t%d\n",ppg,emg,mov,seizure?1:0);
  ws.textAll(line);
  Serial.print(line);
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  sensorsInit();

  if (!LittleFS.begin()) {
    Serial.println("LittleFS Mount Failed");
  } else {
    Serial.println("LittleFS Mounted");
    File root=LittleFS.open("/");
    File file=root.openNextFile();
    while(file){Serial.println(file.name());file=root.openNextFile();}
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID,AP_PASS);
  Serial.print("AP SSID: ");Serial.println(AP_SSID);
  Serial.print("AP PASS: ");Serial.println(AP_PASS);
  Serial.print("AP IP  : ");Serial.println(WiFi.softAPIP());

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(LittleFS, "/index.html", "text/html");
  });
  ws.onEvent([](AsyncWebSocket *server, AsyncWebSocketClient *client,
                AwsEventType type, void *arg, uint8_t *data, size_t len){});
  server.addHandler(&ws);
  server.begin();
}

void loop() {
  static uint32_t last=0;
  uint32_t now=millis();
  if(now-last>=SAMPLE_MS){last=now;sendOneRow();}
}
