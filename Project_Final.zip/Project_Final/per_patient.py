import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Constants
SEQ_LEN = 1
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Model definition
class ChronoNet(nn.Module):
    def __init__(self, input_channels=3, seq_len=SEQ_LEN):
        super(ChronoNet, self).__init__()
        self.conv1 = nn.Conv1d(input_channels, 32, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=11, padding=5)
        self.conv3 = nn.Conv1d(64, 128, kernel_size=21, padding=10)
        self.relu = nn.ReLU()
        self.lstm = nn.LSTM(input_size=128, hidden_size=64, batch_first=True)
        self.fc = nn.Linear(64, 2)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.relu(self.conv3(x))
        x = x.permute(0, 2, 1)
        _, (hn, _) = self.lstm(x)
        out = self.fc(hn[-1])
        return out

# Load model
model = ChronoNet().to(DEVICE)
model.load_state_dict(torch.load("chrononet_seizure_detector.pth", map_location=DEVICE))
model.eval()

# Load and normalize data
df = pd.read_csv("unseen_data_multi_patient.csv")
features = ['PPG', 'EMG', 'MOV']
scaler = MinMaxScaler()
df[features] = scaler.fit_transform(df[features])  # Ideally use same scaler as training

# Get unique patients
patient_ids = df['Patient_ID'].unique()

print("🧠 Inference Results Per Patient:")
for pid in patient_ids:
    patient_df = df[df['Patient_ID'] == pid][features]
    patient_data = patient_df.values

    if len(patient_data) < SEQ_LEN:
        continue  # Skip if not enough data

    # Create sequences
    sequences = []
    for j in range(len(patient_data) - SEQ_LEN + 1):
        sequences.append(patient_data[j:j+SEQ_LEN])
    sequences = np.array(sequences)

    # Inference
    seizure_votes = 0
    for seq in sequences:
        x = torch.tensor(seq[np.newaxis, :, :], dtype=torch.float32).to(DEVICE)
        with torch.no_grad():
            output = model(x)
            pred = torch.argmax(output, dim=1).item()
            seizure_votes += pred

    # Majority vote
    label = 1 if seizure_votes > len(sequences) // 2 else 0
    print(f"🧍 Patient {pid}: {' Seizure Detected : 1' if label == 1 else ' No Seizure Detected : 0'}")
