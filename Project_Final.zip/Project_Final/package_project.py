import zipfile
import os

project_name = "seizure_detection_project"
output_zip = f"{project_name}.zip"
file_list = [
    "model.py",
    "main.py",
    "final_fyp_dataset.csv",
    "chrononet_seizure_detection.pth",
    "emg_scaler.pkl",
    "save_scaler.py",
    "real_time_inference.py",
    "setup.sh",
    "requirements.txt",
    "README.md"
]

with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for file in file_list:
        if os.path.exists(file):
            zipf.write(file)
        else:
            print(f"⚠️ Missing file: {file}")

print(f"\n✅ Project packaged as {output_zip}")
