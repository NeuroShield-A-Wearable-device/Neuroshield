import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Constants
SEQ_LEN = 30
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Model definition
class ChronoNet(nn.Module):
    def __init__(self, input_channels=3, seq_len=SEQ_LEN):
        super(ChronoNet, self).__init__()
        self.conv1 = nn.Conv1d(input_channels, 32, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=11, padding=5)
        self.conv3 = nn.Conv1d(64, 128, kernel_size=21, padding=10)
        self.relu = nn.ReLU()
        self.lstm = nn.LSTM(input_size=128, hidden_size=64, batch_first=True)
        self.fc = nn.Linear(64, 2)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.relu(self.conv3(x))
        x = x.permute(0, 2, 1)
        _, (hn, _) = self.lstm(x)
        out = self.fc(hn[-1])
        return out

# Load model
model = ChronoNet().to(DEVICE)
model.load_state_dict(torch.load("chrononet_seizure_detector.pth", map_location=DEVICE))
model.eval()

# 1. Load unseen data
df = pd.read_csv("unseen_data_multi_patient.csv")

# 2. Normalize with MinMaxScaler
features = ['PPG', 'EMG', 'MOV']
scaler = MinMaxScaler()
df[features] = scaler.fit_transform(df[features])  # Ideally, use the original scaler from training

# 3. Create sequences
def create_sequences(data, seq_len=SEQ_LEN):
    sequences = []
    for i in range(len(data) - seq_len):
        seq = data[i:i+seq_len]
        sequences.append(seq)
    return np.array(sequences)

sequences = create_sequences(df[features].values)

# 4. Run inference
for i, seq in enumerate(sequences):
    x = torch.tensor(seq[np.newaxis, :, :], dtype=torch.float32).to(DEVICE)
    with torch.no_grad():
        output = model(x)
        pred = torch.argmax(output, dim=1).item()
        print(f"Window {i+1}: {'⚠️ Seizure Detected' if pred == 1 else '✅ No Seizure'}")
