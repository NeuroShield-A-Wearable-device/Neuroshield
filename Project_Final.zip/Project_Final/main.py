# main.py

import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import StandardScaler
from model import ChronoNet
import pickle
import time

# Load scaler
with open("emg_scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

# Load the model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = ChronoNet(input_channels=3, n_classes=2).to(device)
model.load_state_dict(torch.load("chrononet_seizure_detection.pth", map_location=device))
model.eval()

# Simulate real-time data stream from your CSV
df = pd.read_csv("final_fyp_dataset.csv")
df = df.drop(columns=["Patient_ID"])  # Adjust if needed

# Apply the scaler
scaled_data = scaler.transform(df.values)

# Inference loop (batch of 1 for real-time simulation)
print("Starting real-time seizure detection...\n")
for i in range(len(scaled_data)):
    sample = scaled_data[i].reshape(1, -1)  # (1, features)
    sample_tensor = torch.FloatTensor(sample).unsqueeze(1).to(device)  # (1, 1, features)
    sample_tensor = sample_tensor.permute(0, 2, 1)  # (1, channels=features, time=1)

    output = model(sample_tensor)
    pred = torch.argmax(output, dim=1).item()

    status = "🚨 Seizure Detected!" if pred == 1 else "✅ No Seizure"
    print(f"[{i+1}] {status}")

    time.sleep(0.01)  # Simulate streaming delay
