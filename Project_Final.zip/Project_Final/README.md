# Seizure Detection Using ChronoNet

This project performs real-time seizure detection using multimodal biosignals (EMG, PPG, Movement) with a ChronoNet deep learning model.

## 📁 Files

- `model.py` – ChronoNet model
- `main.py` – Real-time inference entry point
- `final_fyp_dataset.csv` – Your dataset
- `emg_scaler.pkl` – Preprocessing scaler
- `chrononet_seizure_detection.pth` – Trained model
- `save_scaler.py` – Script to create the scaler
- `real_time_inference.py` – Utility for testing the model
- `requirements.txt` – Dependencies
- `setup.sh` – Easy setup and execution

## ▶️ How to Run

```bash
./setup.sh
