# Imports
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader, Dataset
import numpy as np
import random
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tqdm import tqdm
import matplotlib.pyplot as plt

# Set random seeds
random.seed(42)
np.random.seed(42)
torch.manual_seed(42)
torch.backends.cudnn.deterministic = True

# 1. Load Dataset
data = pd.read_csv('/kaggle/input/final-fyp-dataset/final_fyp_dataset.csv')

# Create patient IDs
data['Patient_ID'] = ['Patient_' + str(i+1).zfill(3) for i in range(len(data))]

# Split into features and labels
X = data.drop(['Patient_ID', 'Seizure_Label'], axis=1).values
y = data['Seizure_Label'].values

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Train-validation split
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 2. Dataset class
class FYPDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X).unsqueeze(2)  # (B, Time, 1)
        self.y = torch.LongTensor(y)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

train_dataset = FYPDataset(X_train, y_train)
val_dataset = FYPDataset(X_val, y_val)

batch_size = 128
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

print("DataLoaders initialized.")

# 3. ChronoNet Model
class ChronoNet(nn.Module):
    def __init__(self, input_channels=3, n_classes=2):
        super(ChronoNet, self).__init__()

        self.conv1 = nn.Conv1d(input_channels, 32, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(input_channels, 32, kernel_size=11, padding=5)
        self.conv3 = nn.Conv1d(input_channels, 32, kernel_size=21, padding=10)

        self.bn1 = nn.BatchNorm1d(32)
        self.bn2 = nn.BatchNorm1d(32)
        self.bn3 = nn.BatchNorm1d(32)

        self.conv_merge = nn.Conv1d(96, 64, kernel_size=3, padding=1)
        self.bn_merge = nn.BatchNorm1d(64)

        self.gru = nn.GRU(input_size=64, hidden_size=64, batch_first=True)

        self.fc = nn.Linear(64, n_classes)

    def forward(self, x):
        x = x.permute(0, 2, 1)  # (B, Channels, Time)

        x1 = F.relu(self.bn1(self.conv1(x)))
        x2 = F.relu(self.bn2(self.conv2(x)))
        x3 = F.relu(self.bn3(self.conv3(x)))

        x = torch.cat([x1, x2, x3], dim=1)

        x = F.relu(self.bn_merge(self.conv_merge(x)))

        x = x.permute(0, 2, 1)  # (B, Time, Features)

        _, hidden = self.gru(x)
        out = self.fc(hidden.squeeze(0))  # remove extra dimension

        return out

# 4. Optimizer, Scheduler, Warmup
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

model = ChronoNet(input_channels=1, n_classes=2).to(device)

criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=1e-3)

scheduler = ReduceLROnPlateau(optimizer, mode='min', patience=5, factor=0.5)

# Warmup Scheduler
class WarmupScheduler:
    def __init__(self, optimizer, warmup_steps, initial_lr, target_lr):
        self.optimizer = optimizer
        self.warmup_steps = warmup_steps
        self.current_step = 0
        self.initial_lr = initial_lr
        self.target_lr = target_lr

    def step(self):
        self.current_step += 1
        if self.current_step <= self.warmup_steps:
            lr = self.initial_lr + (self.target_lr - self.initial_lr) * (self.current_step / self.warmup_steps)
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr

warmup_steps = 5
warmup_scheduler = WarmupScheduler(optimizer, warmup_steps, 1e-5, 1e-3)

# 5. Training Loop
epochs = 30
train_losses = []
val_losses = []
val_accuracies = []

for epoch in range(epochs):
    model.train()
    running_loss = 0.0

    loop = tqdm(train_loader, leave=False)
    for X_batch, y_batch in loop:
        X_batch, y_batch = X_batch.to(device), y_batch.to(device)

        optimizer.zero_grad()
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        loop.set_description(f"Epoch [{epoch+1}/{epochs}]")
        loop.set_postfix(loss=loss.item())

    train_loss = running_loss / len(train_loader)
    train_losses.append(train_loss)

    # Validation
    model.eval()
    val_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for X_batch, y_batch in val_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            val_loss += loss.item()

            preds = torch.argmax(outputs, dim=1)
            correct += (preds == y_batch).sum().item()
            total += y_batch.size(0)

    val_loss /= len(val_loader)
    val_losses.append(val_loss)
    val_acc = correct / total
    val_accuracies.append(val_acc)

    warmup_scheduler.step()  # Warmup step
    scheduler.step(val_loss) # Plateau scheduler step

    print(f"\nEpoch [{epoch+1}/{epochs}] => Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f}")

# 6. Plot results
plt.figure(figsize=(12,5))

plt.subplot(1,2,1)
plt.plot(train_losses, label='Train Loss')
plt.plot(val_losses, label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Loss over Epochs')
plt.legend()

plt.subplot(1,2,2)
plt.plot(val_accuracies, label='Validation Accuracy', color='green')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.title('Validation Accuracy over Epochs')
plt.legend()

plt.show()
