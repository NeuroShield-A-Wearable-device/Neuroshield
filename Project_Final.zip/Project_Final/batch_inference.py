# batch_inference.py

import pandas as pd
import torch
import pickle
from model import ChronoNet
from sklearn.preprocessing import StandardScaler
import numpy as np

# Load model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = ChronoNet(input_channels=3, n_classes=2).to(device)
model.load_state_dict(torch.load("chrononet_seizure_detection.pth", map_location=device))
model.eval()

# Load scaler
with open("emg_scaler.pkl", "rb") as f:
    scaler: StandardScaler = pickle.load(f)

# Load unseen data
data = pd.read_csv("unseen_data.csv")

results = []

# Group by Patient_ID and use 300 samples each
for pid, group in data.groupby("Patient_ID"):
    if len(group) < 300:
        print(f"Skipping {pid} (not enough samples)")
        continue

    sample = group[["PPG", "EMG", "MOV"]].iloc[:300].values
    sample_scaled = scaler.transform(sample)
    tensor_input = torch.FloatTensor(sample_scaled).unsqueeze(0).to(device)

    with torch.no_grad():
        output = model(tensor_input)
        prediction = torch.argmax(output, dim=1).item()

    results.append({"Patient_ID": pid, "Prediction": prediction})

# Save results
result_df = pd.DataFrame(results)
result_df.to_csv("prediction_results.csv", index=False)
print("✅ Inference complete. Results saved to prediction_results.csv")
