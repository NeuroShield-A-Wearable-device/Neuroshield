#!/bin/bash

echo "🚀 Setting up the virtual environment..."
python3 -m venv venv
source venv/bin/activate

echo "📦 Installing requirements..."
pip install --upgrade pip
pip install -r requirements.txt

echo "✅ Setup complete!"
echo "🧠 Running seizure detection..."
python main.py
