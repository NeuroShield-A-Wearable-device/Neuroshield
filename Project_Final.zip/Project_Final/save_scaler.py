# save_scaler.py

import pandas as pd
import pickle
from sklearn.preprocessing import StandardScaler

# Load your full dataset (without labels if possible)
data = pd.read_csv('final_fyp_dataset.csv')

# Select only the signal columns (exclude labels and Patient_ID)
signal_columns = [col for col in data.columns if col not in ['Seizure_Label', 'Patient_ID']]
X = data[signal_columns].values

# Fit the scaler on full data
scaler = StandardScaler()
scaler.fit(X)

# Save the fitted scaler
with open("emg_scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

print("✅ Scaler saved as 'emg_scaler.pkl'")
